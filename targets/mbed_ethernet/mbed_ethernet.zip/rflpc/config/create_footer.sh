cat >> $1 <<EOF
#endif /* RFLPC_CONFIG_OPTIONS_H__ */
EOF
